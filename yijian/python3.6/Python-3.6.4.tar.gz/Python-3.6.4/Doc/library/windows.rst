.. _mswin-specific-services:

****************************
MS Windows Specific Services
****************************

This chapter describes modules that are only available on MS Windows platforms.


.. toctree::

   msilib.rst
   msvcrt.rst
   winreg.rst
   winsound.rst
